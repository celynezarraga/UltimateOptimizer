package com.example.celynezarraga15.ultimateoptimizer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.TreeSet;

public class OptimizerActivity extends AppCompatActivity {

    String finalObjFunction;
    String finalVars;
    HashMap<String,Float> variables;
    Integer error = 0;
    Integer iterationNumber = 0;
    ArrayList<String> inputConstraints;
    ArrayList<String> evaluatedConstraints;
    ArrayAdapter<String> itemsAdapter;
    ArrayList<String> columnHeaders;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_optimizer);

        Switch mySwitch = (Switch) findViewById(R.id.toggleSwitch);

        //set the switch to ON
        mySwitch.setChecked(true);
        //attach a listener to check for changes in state
        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    //
                }else{
                    //
                }
            }
        });

        inputConstraints = new ArrayList<String>();
        evaluatedConstraints = new ArrayList<String>();
        columnHeaders = new ArrayList<String>();

        ListView lvItems = (ListView) findViewById(R.id.listView);
        variables = new HashMap<String, Float>();
        itemsAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, inputConstraints);
        lvItems.setAdapter(itemsAdapter);
    }

    public void solve(View view){
        finalObjFunction = "";
        finalVars = "";

        if(inputConstraints.size() == 0){
            Toast.makeText(this, "No constraints!", Toast.LENGTH_LONG).show();
            error = 1;
        }

        parseObjectiveFunction();

        for(int x=0; x<evaluatedConstraints.size(); x++){
            finalVars = finalVars.concat("\n" + evaluatedConstraints.get(x));
        }

        if(error==0){

            float[][] initialTableu = setUpInitialTableu();
            printTable(initialTableu);

            while(hasNegative(initialTableu)){
                initialTableu = simplexMethod(initialTableu);
                printTable(initialTableu);
            }

            Intent intent = new Intent(this, OptimizerResult.class);
            Bundle bundle = new Bundle();
            bundle.putString("obj", finalObjFunction);
            bundle.putString("vars", finalVars);
            intent.putExtras(bundle);

            startActivity(intent);
        }

        variables.clear();
    }

    public void parseObjectiveFunction(){
        EditText inputobjfunc = (EditText) findViewById(R.id.inputObjectiveFunction);
        String temp1 = inputobjfunc.getText().toString();

        if(temp1.length() == 0){
            Toast.makeText(this,"No Objective Function!", Toast.LENGTH_LONG).show();
            error=1;
        }
        else if(!(temp1.contains("="))){
            Toast.makeText(this,"Invalid Objective Function!", Toast.LENGTH_LONG).show();
        }
        else{
            temp1 = temp1.replaceAll("\\s","");
            temp1 = temp1.replaceAll("-","+-");
            String[] varsFunc = temp1.split("=");

            if(varsFunc[1].length() == 1){
                String temp = varsFunc[1];
                varsFunc[1] = varsFunc[0];
                varsFunc[0] = temp;
            }

            finalVars = finalVars.concat("Variable to solve = " + varsFunc[0] + "\n");
            finalObjFunction = finalObjFunction.concat(varsFunc[0] + " = ");

            String[] polynomials = varsFunc[1].split("\\+");

            for(int i=0; i<polynomials.length; i++){
                if(i==(polynomials.length-1)){
                    finalObjFunction = finalObjFunction.concat(polynomials[i]);
                }
                else{
                    finalObjFunction = finalObjFunction.concat(polynomials[i] + " + ");
                }

                if(!(variables.containsKey(polynomials[i]))){
                    if((polynomials[i].length() == 1) && (!polynomials[i].matches("^.*[^a-zA-Z].*$"))){
                        variables.put(polynomials[i],1f);
                    }
                    if(polynomials[i].length() > 1){
                        String temp = polynomials[i].substring(polynomials[i].length()-1);
                        polynomials[i] = polynomials[i].substring(0, polynomials[i].length()-1);
                        if((polynomials[i].length() == 1) && (polynomials[i].equalsIgnoreCase("-"))){
                            polynomials[i] = polynomials[i].concat("1");
                        }

                        Float x = Float.parseFloat(polynomials[i]);

                        if(!temp.matches("^.*[^a-zA-Z].*$")){
                            variables.put(temp,x);
                        }
                        else{
                            Toast.makeText(this,"Invalid variable!", Toast.LENGTH_LONG).show();
                            error=1;
                        }
                    }
                }else {
                    Toast.makeText(this, "Duplicate variables in objective function!", Toast.LENGTH_LONG).show();
                    error = 1;
                }

            }

            for ( String key : variables.keySet() ) {
                finalVars = finalVars.concat( key + "=" + variables.get(key) + "\n");
            }
        }
    }

    public Boolean evaluateConstraints(){
        EditText newCons = (EditText) findViewById(R.id.cons);
        String itemText = newCons.getText().toString();
        String[] cons;
        int ch = 0;

        if(itemText.length() == 0){
            Toast.makeText(this, "Empty constraint!", Toast.LENGTH_LONG).show();
            return false;
        }
        else{
            itemText = itemText.replaceAll("\\s","");

            if(inputConstraints.contains(itemText)){
                Toast.makeText(this, "Constraint already exists!", Toast.LENGTH_LONG).show();
                return false;
            }

            if(itemText.contains("<=")){
                cons = itemText.split("<=");
            }
            else if(itemText.contains(">=")){
                cons = itemText.split(">=");
                ch = 1;
            }
            else if(itemText.contains("=")){
                cons = itemText.split("=");
            }
            else if(itemText.contains("<")){
                cons = itemText.split("<");
            }
            else if(itemText.contains(">")){
                cons = itemText.split(">");
                ch = 1;
            }
            else{
                Toast.makeText(this, "Invalid constraint", Toast.LENGTH_LONG).show();
                return false;
            }

            if(!cons[0].matches("^.*[^0-9].*$")) {
                String temp = cons[1];
                cons[1] = cons[0];
                cons[0] = temp;
                if(ch==0){
                    ch=1;
                }
                else{
                    ch=0;
                }
            }

            String consVar = "S";
            consVar = consVar.concat(String.valueOf((evaluatedConstraints.size())+1));

            if(ch == 0){
                cons[0] = cons[0].concat("+" + consVar + "=" + cons[1]);
            }
            else{
                cons[0] = cons[0].concat("-" + consVar + "=" + cons[1]);
            }
            evaluatedConstraints.add(cons[0]);

            return true;
        }
    }

    public void addConstraint(View view){

        if(evaluateConstraints() == true){
            EditText newCons = (EditText) findViewById(R.id.cons);
            String itemText = newCons.getText().toString();
            itemText = itemText.replaceAll("\\s","");

            inputConstraints.add(itemText);
            newCons.setText("");
        }
    }

    public float[][] setUpInitialTableu(){

        for(String key: new TreeSet<String>(variables.keySet())) {
            columnHeaders.add(key);
        }
        for(int i=0; i<evaluatedConstraints.size();i++){
            columnHeaders.add("S".concat(String.valueOf(i+1)));
        }
        columnHeaders.add(String.valueOf(finalObjFunction.charAt(0)));
        columnHeaders.add("Solution");

        int rows = evaluatedConstraints.size() + 1;
        int cols = variables.size() + 1 + rows;

        float[][] tableu = new float[rows][cols];

        for(int i=0; i<rows; i++){
            for(int j=0; j<cols; j++){
                tableu[i][j] = 0;
            }
        }

        for(int i=0; i<rows;i++){
            HashMap<String,Float> coeff;

            if(i==(rows-1)){
                coeff = variables;
            }
            else{
                coeff = getCoefficients(evaluatedConstraints.get(i));
            }

            for(int j=0; j<columnHeaders.size();j++){
                if(coeff.containsKey(columnHeaders.get(j))){
                    tableu[i][j] = coeff.get(columnHeaders.get(j));

                    if(i == (rows-1)){
                        tableu[i][j] = -1 * tableu[i][j];
                    }
                }
                else{
                    tableu[i][j] = 0;
                }
            }
            tableu[rows-1][cols-2] = 1;
        }

        return tableu;
    }

    public HashMap<String,Float> getCoefficients(String eq){
        HashMap<String,Float> coeff = new HashMap<String, Float>();

        String temp1 = eq.replaceAll("-","+-");
        String[] varsFunc = temp1.split("=");

        coeff.put("Solution",Float.parseFloat(varsFunc[1]));

        String[] polynomials = varsFunc[0].split("\\+");
        for(int i=0; i<polynomials.length;i++){
            if(!(coeff.containsKey(polynomials[i]))){
                if((polynomials[i].length() == 1) && (!polynomials[i].matches("^.*[^a-zA-Z].*$"))){
                    coeff.put(polynomials[i],1f);
                }
                else if((polynomials[i].length() > 1) && (polynomials[i].charAt(0)=='S')){
                    coeff.put(polynomials[i],1f);
                }
                else if((polynomials[i].length() > 1) && (polynomials[i].substring(0,2).equalsIgnoreCase("-S"))){
                    coeff.put(polynomials[i].substring(1,3),-1f);
                }
                else{
                    String temp = polynomials[i].substring(polynomials[i].length()-1);
                    polynomials[i] = polynomials[i].substring(0, polynomials[i].length()-1);
                    if((polynomials[i].length() == 1) && (polynomials[i].equalsIgnoreCase("-"))){
                        polynomials[i] = polynomials[i].concat("1");
                    }
                    Float x = Float.parseFloat(polynomials[i]);
                    if(!temp.matches("^.*[^a-zA-Z].*$")){
                        coeff.put(temp,x);
                    }
                    else{
                        Toast.makeText(this,"Invalid variable!", Toast.LENGTH_LONG).show();
                        error=1;
                    }
                }
            }else {
                Toast.makeText(this, "Duplicate variables in constraint!", Toast.LENGTH_LONG).show();
                error = 1;
            }
        }
        return coeff;
    }

    public void printTable(float[][] table){
//        finalVars = finalVars.concat("\n\nIteration " + iterationNumber + ":\n");

        System.out.println("\n\nIteration " + iterationNumber + ":\n");

        for(int i=0; i<columnHeaders.size();i++){
            System.out.print(columnHeaders.get(i) + "\t");
//            finalVars = finalVars.concat(columnHeaders.get(i) + "\t");
            if(i != (columnHeaders.size() -1)){
//                finalVars = finalVars.concat("|\t");
                System.out.print("|\t");
            }
        }
        for(float[] row : table) {
//            finalVars = finalVars.concat("\n");
            System.out.println();
            for(int i=0; i<row.length; i++){
//                finalVars = finalVars.concat(row[i] + "\t");
                System.out.print(row[i]);
                System.out.print("\t");

                if(i != (row.length -1)){
//                    finalVars = finalVars.concat("|\t");
                    System.out.print("|\t");
                }
            }
        }

        getBasicSolution(table);
        iterationNumber++;
    }

    public void getBasicSolution(float[][] table){
       HashMap<String, Float> basicSolution = new HashMap<String, Float>();

       String solution = "\nBasic Solution: \n";

       for(int j=0; j<(columnHeaders.size()-1);j++){     //col
           int numofnotzeros = 0;
           int x = -1;

           for(int i=0; i<table.length;i++){    //row
               if(table[i][j] != 0){
                   numofnotzeros++;
                   x = i;
               }
           }

           if(numofnotzeros == 1){
               if((table[x][(table[0].length)-1]) == 0){
                   basicSolution.put(columnHeaders.get(j),0f);
               }
               else{
                   float z = (table[x][(table[0].length)-1]) / (table[x][j]);
                   basicSolution.put(columnHeaders.get(j),z);
               }
           }
           else{
               basicSolution.put(columnHeaders.get(j),0f);
           }
       }

        for(int i=0; i<columnHeaders.size()-1; i++){
            solution = solution.concat("\t" + columnHeaders.get(i) + "=" + basicSolution.get(columnHeaders.get(i)));
        }

        finalVars = finalVars.concat(solution + "\n");
        System.out.println("\n" + solution + "\n");
//        return basicSolution;
    }

    public float[][] simplexMethod(float[][] table){

        int row = table.length;
        int col = table[0].length;

        //get pivot column
        float minNegative = 0;
        int pivotColumn = -1;
        for(int i=0; i<(col-1);i++){
            if((table[row-1][i] < 0) && (table[row-1][i] < minNegative)){
                minNegative = table[row-1][i];
                pivotColumn = i;
            }
        }

//        finalVars = finalVars.concat("\nPivot Column: " + pivotColumn + "Value: " + minNegative +"\n");

        //get pivot row
        float minRatio = 9999999;
        int pivotRow = -1;
        for(int i=0; i<(row-1);i++){
            if(table[i][pivotColumn] > 0){
                float x = table[i][col-1] / table[i][pivotColumn];
                if((minRatio > x) && (x>=0)){
                    minRatio = x;
                    pivotRow = i;
                }
            }
        }

//        finalVars = finalVars.concat("\nPivot Row: " + pivotRow + "Value: " + minRatio +"\n");

//        System.out.println("Pivot Row: " + pivotRow);
//        System.out.println("Pivot Column: " + pivotColumn);
//        System.out.println("Pivot Element: " + table[pivotRow][pivotColumn]);

        table = gaussJordan(table,pivotRow,pivotColumn);
        return table;
    }

    public float[][] gaussJordan(float[][] table, int pivotRow, int pivotColumn){
        int row = table.length;
        int col = table[0].length;
        float[] sRow = new float[col];
        float pivotElement = table[pivotRow][pivotColumn];

        //normalize
        for(int i=0; i<col; i++){
            table[pivotRow][i] = table[pivotRow][i] / pivotElement;
        }

        for(int i=0; i<row; i++){
            if(i!=pivotRow) {
                for (int x = 0; x < sRow.length; x++) {
                    sRow[x] = table[pivotRow][x] * table[i][pivotColumn];
                }

                for (int j = 0; j < col; j++) {
                    table[i][j] = table[i][j] - sRow[j];
                }
            }
        }

        return table;
    }

    public Boolean hasNegative(float[][] table){
        int row = table.length;
        int col = table[0].length;

        for(int i=0; i<(col-1);i++){
            if((table[row-1][i] < 0)){
                return true;
            }
        }

        return false;
    }
}
