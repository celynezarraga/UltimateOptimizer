package com.example.celynezarraga15.ultimateoptimizer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class OptimizerResult extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_optimizer_result);

        Bundle b=this.getIntent().getExtras();
        String finalObjFunction = b.getString("obj");
        String finalVars = b.getString("vars");

        TextView objfunc = (TextView) findViewById(R.id.objfunction);
        objfunc.setText(finalObjFunction);
        TextView vars = (TextView) findViewById(R.id.var);
        vars.setText(finalVars);
    }
}
